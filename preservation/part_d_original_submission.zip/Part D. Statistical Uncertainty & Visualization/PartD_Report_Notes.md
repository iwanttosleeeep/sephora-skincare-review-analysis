# Part D: Statistical Uncertainty & Visualization

All numbers below are produced by `04_uncertainty_D.ipynb`. Re-run the notebook to refresh
them. Seed 5106, B = 2000 product-level bootstrap replicates.

---

## 1. What Part D adds

| Part | What it reports | Kind of uncertainty |
| --- | --- | --- |
| C — EDA | Five-star rate by price, category, skin type | **none** (point estimates only) |
| E — model | Odds ratios and predicted probabilities | **model-based** (clustered SEs from logistic regression) |
| **D — this part** | Group rates, differences, and the interaction | **design-based** (product-level bootstrap) |

D answers a question neither C nor E answers: *how much of the pattern in the sample is
just noise?* It makes no model assumption, so it also acts as a check on E's model-based
intervals and the interaction test.

---

## 2. Method (report-ready paragraph)

> Reviews of the same product are not independent, so we quantify uncertainty with a
> product-level bootstrap. In each of 2,000 replicates we resampled the 2,351 products with
> replacement and pooled every review of the drawn products, so a product's reviews enter
> and leave the sample together. We recomputed the group rates, the differences between
> groups, and the price gradient within each skin type. Intervals are the 2.5th and 97.5th
> percentiles of the bootstrap distribution. Every statistic uses the same 2,000 draws, so
> a difference is computed inside a replicate instead of being assembled from two separate
> intervals. The intraclass correlation of the five-star outcome across products is 0.049.

**Why it matters.** With reviews treated as independent, the standard error of the overall
rate is 0.046 pp; the product bootstrap gives 0.40 pp. The measured design effect is about
75, so the **effective sample size is roughly 14,600 reviews, not 1,093,847**. That is
closer to the number of products (2,351) than to the number of reviews.

---

## 3. Key results

### 3.1 Overall

Five-star rate **63.86%** (95% CI **63.08 – 64.62**).

### 3.2 Price segment

| Segment | Rate | 95% CI | Difference vs overall |
| --- | --- | --- | --- |
| Budget (<$25) | 63.88% | 61.81 – 65.70 | +0.02 pp |
| Mid ($25–49) | 64.27% | 63.18 – 65.38 | +0.41 pp |
| Premium ($50–99) | 63.89% | 62.52 – 65.27 | +0.03 pp |
| Luxury ($100+) | 60.94% | 57.98 – 63.76 | **−2.92 pp** (−5.84 to −0.14) |

The three lower segments are indistinguishable from each other and from the overall rate.
Luxury is the lowest by about 3 pp, but even that interval is wide.

**The decisive table, pairwise comparisons:**

| Comparison | Difference | Bootstrap p | Naive p |
| --- | --- | --- | --- |
| Budget vs Mid | −0.39 pp | 0.741 | 9.2 × 10⁻⁴ |
| Budget vs Premium | −0.01 pp | 0.989 | 0.940 |
| Budget vs Luxury | +2.93 pp | 0.104 | 5.3 × 10⁻⁴⁴ |
| Mid vs Premium | +0.38 pp | 0.669 | 5.8 × 10⁻⁴ |
| Mid vs Luxury | +3.32 pp | **0.037** | 1.2 × 10⁻⁶⁰ |
| Premium vs Luxury | +2.94 pp | 0.073 | 5.9 × 10⁻⁴⁶ |

Naive independent-review standard errors call **5 of 6** pairs significant; the
product-level bootstrap calls **1**. This is the single clearest justification for Part D.

### 3.3 Reviewer skin type

| Skin type | Rate | 95% CI |
| --- | --- | --- |
| Normal | 63.67% | 62.83 – 64.50 |
| Combination | 63.73% | 62.93 – 64.51 |
| Dry | 64.08% | 63.23 – 64.88 |
| Oily | 62.90% | 62.02 – 63.74 |
| Not reported | 66.16% | 64.62 – 67.56 |

The four reported types span 1.2 pp and their intervals overlap almost completely.
Not reporting skin type is associated with a **higher** rate (+2.30 pp, CI 1.06 – 3.43).
This matches Part E's "Skin: Not reported" odds ratio of 1.20.

### 3.4 Product category

| Category | Rate | 95% CI |
| --- | --- | --- |
| Eye Care | 56.70% | 54.38 – 59.05 |
| Tools, Wellness & Self-Tan | 59.76% | 56.69 – 63.35 |
| Sunscreen | 60.11% | 55.96 – 63.24 |
| Treatments | 63.40% | 61.79 – 64.85 |
| Moisturizers | 63.92% | 62.45 – 65.40 |
| Minis & Sets | 64.06% | 61.25 – 66.84 |
| Cleansers | 66.17% | 64.24 – 68.03 |
| Masks | 66.45% | 64.38 – 68.73 |
| Lip Care | 67.55% | 62.60 – 70.66 |

Category is the only grouping variable with clear, robust differences: Eye Care is
7.2 pp below the overall rate (CI −9.44 to −4.93) and six of the nine category differences
exclude zero. This supports Part E's main finding and gives it a design-based footing.

### 3.5 Skin type × price segment interaction

Price gradient (Luxury − Budget) within each skin type, in percentage points:

| Skin type | Gradient | 95% CI |
| --- | --- | --- |
| Normal | −1.68 | −5.30 to +2.21 |
| Combination | −2.87 | −6.58 to +0.95 |
| Dry | −2.93 | −6.46 to +0.79 |
| Oily | −3.28 | −6.78 to +0.31 |
| *Not reported* | *−4.79* | *−9.26 to −0.37* (excluded from the test) |

Bootstrap test of equal gradients (four reported skin types): **T = 1.60 pp, p = 0.19**.

Part E's joint Wald test on the model's 12 interaction terms gave χ²(12) = 11.33,
p = 0.50. Two different routes, same conclusion: **no evidence that the price–satisfaction
relationship differs by skin type**. The observed cell rates and the model predictions
agree at all 20 cells (Figure D5), so the flat interaction is a property of the data, not
an artefact of the model.

---

## 4. Figures

| File | What it shows | Suggested caption |
| --- | --- | --- |
| `figures/D1_group_rates_ci.png` | Five-star rate by price segment, skin type and category with 95% product-bootstrap intervals | Five-star rate by group with 95% confidence intervals from a product-level bootstrap (2,000 replicates). A bar is wider when fewer products carry the reviews. |
| `figures/D2_interaction_plot.png` | Interaction plot: rate by price segment, one line per skin type | Five-star rate by price segment and skin type. The lines are nearly parallel: the price pattern is the same order of magnitude in every skin type. |
| `figures/D3_price_gradient_by_skin.png` | Luxury − Budget gradient per skin type with intervals | Difference in five-star rate between luxury and budget products within each skin type. All four reported intervals cross zero. |
| `figures/D4_naive_vs_cluster_ci.png` | Naive Wilson vs product-bootstrap intervals, with SE ratio | The same rates under independent-review and product-clustered assumptions. The naive intervals are 3–11 times too narrow. |
| `figures/D5_observed_vs_model.png` | Observed cell rates vs Part E's model predictions | Observed five-star rates and Part E's model predictions agree at every skin-type × price cell. |

### 中文要点（自用）

- **D 的卖点**：C 只有点估计，E 的 CI 来自模型。D 用"按产品重抽样"给出**不依赖模型**的
  CI，同时检验了 E 的结论。
- **最强的一句话**：如果把每条评论当独立样本，价格两两比较 6 对里有 5 对"显著"；按产品
  重抽样后只有 1 对显著。有效样本量约 1.46 万，不是 109 万。
- **结论**：类别差异真实（Eye Care 最低，−7.2pp）；价格只有 Luxury 略低且区间很宽；肤质之间
  几乎没有差别；价格×肤质**没有交互**（bootstrap p=0.19，E 的 Wald p=0.50）。
- **必须写进 Limitations**：换成就产品加权，Luxury 反而最高（64.1% vs 60.9%），说明价格结论
  依赖加权方式。

---

## 5. Limitations to add to the report (Part D's contribution)

1. **Weighting.** The bootstrap estimand is the review-weighted rate: a large product
   contributes in proportion to its number of reviews. Under product weighting (each
   product counted once) the overall rate is essentially unchanged (63.11% vs 63.24%) but
   the price ordering reverses: Luxury is lowest at 60.94% by review and highest at 64.10%
   by product. The Budget segment is carried by a few very large, highly rated products.
   The Luxury gap should be read as a statement about the reviews in this sample, not about
   products in general.
2. **Bootstrap limits.** Resampling products treats the observed products as a
   representative sample of the product population. Sephora's catalogue is not a random
   sample of products, and the scraping cap of 200 reviews per product (if real) means
   popular products are under-represented in their own review counts.
3. **Percentile intervals** can be slightly too narrow for strongly skewed statistics;
   BCa intervals would be a refinement. With 2,351 clusters the difference is small.

---

## 6. Q&A preparation (likely questions)

**Q: Why resample products instead of reviews?**
Reviews of the same product are correlated. They share ingredients, price, brand and
marketing. Resampling individual reviews would pretend they are independent and produce
intervals several times too narrow (Figure D4). Resampling products keeps each product's
reviews together and reproduces the real dependence.

**Q: Why not just cluster the standard errors in the regression?**
Part E does that, and for the model coefficients it is the right tool. But the group rates
in Part C are not model quantities, and clustered SEs still rely on the parametric model.
The bootstrap gives intervals with no model assumption, for any statistic including
differences and cell rates, and it works as an independent check.

**Q: What is the design effect and why is it so large?**
It is the ratio of the clustered variance to the variance you would get with independent
reviews. Here it is about 75, because reviews per product range from 1 to 16,115 and the
review-weighted rate is dominated by the largest products. So 1.09 million reviews carry
about as much information as 14,600 independent ones.

**Q: Your interaction p = 0.19, Part E's is 0.50. Do they disagree?**
No. They test different statistics: E tests all 12 interaction coefficients jointly,
D tests whether the single Luxury-minus-Budget gradient is the same across skin types
(a 1-degree-of-freedom-style summary). Both are far from significance and both point to no
interaction.

**Q: Price differences look tiny. Is that a null result?**
It is a small, precise-enough-to-be-informative null for the lower three segments (their
intervals are narrow and overlap), and a wide, inconclusive interval for Luxury. We report
it as "not distinguishable from noise", not as "no effect".

**Q: Why does the category matter more than price?**
Category differences are 7–11 pp wide and survive clustering; price differences are
1–3 pp and do not. Category is a property that changes what the product is, while price
within this catalogue range changes little about the review experience.

---

## 7. AI use log (for the report's AI statement)

| Tool | Use in Part D |
| --- | --- |
| Claude (Anthropic) | Drafted the bootstrap implementation, the vectorised product-by-group counting, the plotting code and initial wording of this note. All statistical choices (cluster bootstrap, percentile intervals, recentred bootstrap test, exclusion of "Not reported" from the interaction test) were reviewed against the data and against Part E's results before being kept. |

Prompt used (summary): *"Design Part D of a STAT5106 project on Sephora skincare reviews:
product-level bootstrap 95% CIs for five-star rates by price segment, category and skin
type, group comparison charts, and a skin type × price segment interaction plot. The main
model is in Part E with clustered SEs; avoid duplicating it."*

> **Check before submission.** The revised guidelines list permitted AI uses as
> "clarifying programming concepts, brainstorming solution strategies, explaining error
> messages, debugging, and improving code readability or documentation", and require every
> functional use to be acknowledged. The paragraphs in section 2 of this file are
> AI-drafted. Rewrite them in your own words so that you can defend them in Q&A, and keep
> the acknowledgement above in the report.

---

## 8. Where Part D earns marks (official rubric, 2026 revised)

| Rubric item | Weight | What Part D contributes |
| --- | --- | --- |
| Presentation 3 — Data visualization | 10% | Figures D1–D5; every plot is labelled, ordered, and shows uncertainty rather than only point estimates |
| Presentation 5 — Presentation of results | 10% | "Include relevant comparisons and **measures of uncertainty** where appropriate" — D is the only part that provides design-based uncertainty; the naive-vs-bootstrap comparison is a self-contained quantitative finding |
| Presentation 6 — Interpretation and conclusions | 10% | "No evidence of an interaction" is a conclusion supported by two independent methods (bootstrap p = 0.19, model Wald p = 0.50) |
| Presentation 7 — Limitations | 10% | The weighting sensitivity (price ordering flips under product weighting) is a concrete, quantified limitation |
| Report 2 — Methods, implementation and reproducibility | 10% | The notebook is self-contained, fixed seed 5106, records package versions and the exact input file; the bootstrap is described precisely enough to re-implement |
| Report 3 — Analysis, validation and results | 10% | D acts as the validation layer: it checks the model-based intervals from Part E against a distribution-free benchmark |

**Line to reuse in the slides:** *"With 1.09 million reviews the naive standard error
suggests almost any difference is significant; once reviews are resampled by product, the
effective sample size is about 14,600 and five of six price comparisons stop being
significant."*

---

## 9. Files

```
Part D. Statistical Uncertainty & Visualization/
├── 04_uncertainty_D.ipynb          # the analysis (self-contained, runs end to end)
├── PartD_Report_Notes.md           # this file
└── outputs/
    ├── ci_group_rates.csv          # rates, CIs, bootstrap & naive SEs, design effects
    ├── ci_differences.csv          # difference vs overall, with CIs and bootstrap p
    ├── ci_pairwise_price.csv       # 6 price pairs: bootstrap vs naive
    ├── ci_skin_x_price_cells.csv   # 20 cells with CIs
    ├── ci_price_gradient_by_skin.csv
    ├── interaction_test.csv
    ├── observed_vs_model.csv
    └── figures/D1–D5 (.png)
```
